#!/bin/bash
echo "Starting MongoDB setup..."

# Jalankan MongoDB
echo "Starting MongoDB service..."
mongod --fork --logpath /var/log/mongodb/mongod.log --dbpath /var/lib/mongodb

# Verifikasi apakah MongoDB berjalan
if pgrep -x "mongod" > /dev/null; then
    echo "MongoDB is running."
else
    echo "MongoDB failed to start!"
    exit 1
fi

echo "MongoDB setup completed."
