#!/bin/bash
echo "Starting Open5GS setup..."

# Pastikan direktori konfigurasi Open5GS tersedia
if [ ! -d "/etc/open5gs" ]; then
    echo "Configuration directory for Open5GS not found!"
    exit 1
fi

# Jalankan layanan Open5GS
echo "Starting Open5GS services..."
open5gs-mmed &
open5gs-sgwcd &
open5gs-pcrfd &
open5gs-hssd &
open5gs-upfd &

# Verifikasi apakah layanan berjalan
if pgrep -x "open5gs-mmed" > /dev/null; then
    echo "Open5GS MME is running."
else
    echo "Open5GS MME failed to start!"
    exit 1
fi

echo "Open5GS setup completed."
