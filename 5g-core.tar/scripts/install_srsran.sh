#!/bin/bash

# Fungsi untuk memeriksa dan memastikan bahwa proses berhasil
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: $1"
        exit 1
    fi
}

echo "Starting installation and configuration of gNodeB and srsUE..."

# Step 1: Konfigurasi gNodeB
echo "Configuring gNodeB..."
cp /etc/srsRAN/gnb.conf.template /etc/srsRAN/gnb.conf
cp /etc/srsRAN/gnb.tac.template /etc/srsRAN/gnb.tac

# Mengganti placeholder MCC, MNC, dan konfigurasi lain (sesuaikan dengan kebutuhan)
sed -i "s|MCC_PLACEHOLDER|001|g" /etc/srsRAN/gnb.conf
sed -i "s|MNC_PLACEHOLDER|01|g" /etc/srsRAN/gnb.conf

echo "gNodeB configuration completed."

# Step 2: Menjalankan gNodeB
echo "Starting gNodeB..."
srsran_gnb --config-file=/etc/srsRAN/gnb.conf > /var/log/gnb.log 2>&1 &
check_status "Failed to start gNodeB."
echo "gNodeB started successfully."

# Step 3: Konfigurasi srsUE
echo "Configuring srsUE..."
cp /etc/srsRAN/ue.conf.template /etc/srsRAN/ue.conf

# Mengganti placeholder konfigurasi sesuai kebutuhan
sed -i "s|PLMN_MCC_PLACEHOLDER|001|g" /etc/srsRAN/ue.conf
sed -i "s|PLMN_MNC_PLACEHOLDER|01|g" /etc/srsRAN/ue.conf

echo "srsUE configuration completed."

# Step 4: Menjalankan srsUE
echo "Starting srsUE..."
srsran_ue --config-file=/etc/srsRAN/ue.conf > /var/log/ue.log 2>&1 &
check_status "Failed to start srsUE."
echo "srsUE started successfully."

# Step 5: Verifikasi proses
echo "Verifying gNodeB and srsUE processes..."
if pgrep -x "srsran_gnb" > /dev/null && pgrep -x "srsran_ue" > /dev/null; then
    echo "Both gNodeB and srsUE are running successfully."
else
    echo "Error: One or both processes failed to start."
    exit 1
fi

echo "gNodeB and srsUE setup completed."
